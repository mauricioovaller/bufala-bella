<?php
require_once($_SERVER['DOCUMENT_ROOT'] . "/DatenBankenApp/fpdf/fpdf.php");
include $_SERVER['DOCUMENT_ROOT'] . "/DatenBankenApp/DiBufala/conexionBaseDatos/conexionbd.php";
require_once __DIR__ . '/consolidacion_reportes_helper.php';
$enlace->set_charset("utf8mb4");
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Verificar si la petición es POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die(json_encode(["error" => "Método no permitido. Usa POST."]));
}

// Obtener los datos enviados en formato JSON
$input = json_decode(file_get_contents("php://input"), true);

// Verificar parámetros
if (!isset($input['fechaDesde']) || !isset($input['fechaHasta']) || !isset($input['tipoFecha'])) {
    die(json_encode(["error" => "Fechas y campo de fecha son requeridos."]));
}

$fechaInicio = $input['fechaDesde'];
$fechaFin = $input['fechaHasta'];
$campoFechaBD = consolidacion_mapear_campo_fecha($input['tipoFecha']);

// Establecer idioma para días de la semana en español
$enlace->query("SET lc_time_names = 'es_ES'");

// Datos de transporte: una fila por Fecha + Guia Master + Guia Hija
// (costo diario prorrateado por cajas; facturas/precintos por Fecha + Guia Master)
$datosTransporte = consolidacion_obtener_transporte_local($enlace, $fechaInicio, $fechaFin, $campoFechaBD);

// CLASE PDF PARA REPORTE DE TRANSPORTE
// ======================
class PDFTransporte extends FPDF
{
    private $totalCajas = 0;
    private $totalPesoNeto = 0;
    private $totalPesoBruto = 0;
    private $totalEstibas = 0;
    private $totalEstibasPagas = 0;
    private $totalCostoTransporte = 0;

    function Header()
    {
        // Logo
        $this->Image($_SERVER['DOCUMENT_ROOT'] . "/DatenBankenApp/DiBufala/img/bufalabella.jpg", 10, 10, 10);

        // Título principal
        $this->SetFont('Arial', 'B', 16);
        $this->Cell(0, 10, utf8_decode('TRANSPORTE POR DÍA'), 0, 1, 'C');
        $this->SetFont('Arial', 'B', 10);
        $this->Cell(0, 6, utf8_decode('DETALLE POR GUIA MASTER / HIJA'), 0, 1, 'C');

        // Información del rango de fechas
        $this->SetFont('Arial', 'I', 10);
        global $fechaInicio, $fechaFin;
        $this->Cell(0, 6, utf8_decode('Período: ' . $fechaInicio . ' a ' . $fechaFin), 0, 1, 'C');
        $this->Ln(5);
    }

    function Footer()
    {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->Cell(0, 10, utf8_decode('Página ') . $this->PageNo() . '/{nb}', 0, 0, 'C');
    }

    function agregarEncabezadoColumnas()
    {
        $this->SetFont('Arial', 'B', 6.5);
        $this->SetFillColor(180, 180, 180);

        // Guardar posición inicial
        $startX = $this->GetX();
        $startY = $this->GetY();

        // FECHA (ancho: 35)
        $this->Cell(40, 8, utf8_decode('FECHA'), 1, 0, 'C', true);

        // CANTIDAD CAJAS (ancho: 15)
        $this->SetXY($startX + 40, $startY);
        $this->MultiCell(17, 4, utf8_decode('CANTIDAD' . "\n" . 'CAJAS'), 1, 'C', true);

        // PESO NETO (KG) (ancho: 18)
        $this->SetXY($startX + 40 + 17, $startY);
        $this->MultiCell(20, 4, utf8_decode('PESO NETO' . "\n" . '(KG)'), 1, 'C', true);

        // PESO BRUTO (KG) (ancho: 20)
        $this->SetXY($startX + 40 + 17 + 20, $startY);
        $this->MultiCell(22, 4, utf8_decode('PESO BRUTO' . "\n" . '(KG)'), 1, 'C', true);

        // GUIA MASTER (ancho: 18)
        $this->SetXY($startX + 40 + 17 + 20 + 22, $startY);
        $this->MultiCell(22, 4, utf8_decode('GUIA' . "\n" . 'MASTER'), 1, 'C', true);

        // GUIA HIJA (ancho: 18)
        $this->SetXY($startX + 40 + 17 + 20 + 22 + 22, $startY);
        $this->MultiCell(22, 4, utf8_decode('GUIA' . "\n" . 'HIJA'), 1, 'C', true);

        // PALLETS (ancho: 12)
        $this->SetXY($startX + 40 + 17 + 20 + 22 + 22 +22, $startY);
        $this->Cell(14, 8, utf8_decode('PALLETS'), 1, 0, 'C', true);

        // PALLETS (ancho: 12)
        $this->SetXY($startX + 40 + 17 + 20 + 22 + 22 + 22 + 14, $startY);
        $this->MultiCell(14, 4, utf8_decode('PALLETS' . "\n" . 'PAGAS'), 1, 'C', true);

        // PALLETS (ancho: 12)
        $this->SetXY($startX + 40 + 17 + 20 + 22 + 22 +22 + 14 + 14, $startY);
         $this->MultiCell(18, 4, utf8_decode('COSTO' . "\n" . 'TRANSPORTE'), 1, 'C', true);

        // FACTURAS (ancho: 22)
        $this->SetXY($startX + 40 + 17 + 20 + 22 + 22 + 22 + 14 + 14 + 18, $startY);
        $this->Cell(22, 8, utf8_decode('FACTURAS'), 1, 0, 'C', true);

        // PRECINTO (ancho: 18)
        $this->SetXY($startX + 40 + 17 + 20 + 22 + 22 + 22 + 14 + 14 + 18 + 22, $startY);
        $this->Cell(18, 8, utf8_decode('PRECINTO'), 1, 1, 'C', true);
    }

    function agregarFila($fecha, $cajas, $pesoNeto, $pesoBruto, $guiaMaster, $guiaHija, $cantidadEstibas, $cantidadEstibasPagas, $costoTransporte, $facturas, $precintos)
    {
        // Verificar si necesita nueva página
        if ($this->GetY() > 250) {
            $this->AddPage();
            $this->agregarEncabezadoColumnas();
        }

        $this->SetFont('Arial', '', 7);
        $this->Cell(40, 7, utf8_decode($fecha), 1);       
        $this->Cell(17, 7, number_format($cajas, 0), 1, 0, 'R');
        $this->Cell(20, 7, number_format($pesoNeto, 2), 1, 0, 'R');
        $this->Cell(22, 7, number_format($pesoBruto, 2), 1, 0, 'R');
        $this->Cell(22, 7, utf8_decode($guiaMaster), 1, 0, 'C');
        $this->Cell(22, 7, utf8_decode($guiaHija), 1, 0, 'C');
        $this->Cell(14, 7, number_format((float)$cantidadEstibas, 0), 1, 0, 'R');
        $this->Cell(14, 7, number_format((float)$cantidadEstibasPagas, 0), 1, 0, 'R');
        $this->Cell(18, 7, number_format((float)$costoTransporte, 0), 1, 0, 'R');
        $this->Cell(22, 7, utf8_decode($facturas), 1, 0, 'C');
        $this->Cell(18, 7, utf8_decode($precintos), 1, 1, 'C');

        // Acumular totales
        $this->totalCajas += $cajas;
        $this->totalPesoNeto += $pesoNeto;
        $this->totalPesoBruto += $pesoBruto;
        $this->totalEstibas += (float)$cantidadEstibas;
        $this->totalEstibasPagas += (float)$cantidadEstibasPagas;
        $this->totalCostoTransporte += (float)$costoTransporte;
    }

    function agregarTotales()
    {
        $this->SetFont('Arial', 'B', 7);
        $this->SetFillColor(220, 220, 220);

        $this->Cell(40, 8, 'TOTALES:', 1, 0, 'R', true);
        $this->Cell(17, 8, number_format($this->totalCajas, 0), 1, 0, 'R', true);
        $this->Cell(20, 8, number_format($this->totalPesoNeto, 2), 1, 0, 'R', true);
        $this->Cell(22, 8, number_format($this->totalPesoBruto, 2), 1, 0, 'R', true);
        $this->Cell(22, 8, '', 1, 0, 'R', true);
        $this->Cell(22, 8, '', 1, 0, 'R', true);
        $this->Cell(14, 8, number_format($this->totalEstibas, 0), 1, 0, 'R', true);
        $this->Cell(14, 8, number_format($this->totalEstibasPagas, 0), 1, 0, 'R', true);
        $this->Cell(18, 8, number_format($this->totalCostoTransporte, 0), 1, 0, 'R', true);
        $this->Cell(22, 8, '', 1, 0, 'R', true);
        $this->Cell(18, 8, '', 1, 1, 'R', true);
    }
}

// ======================
// GENERAR PDF
// ======================
$pdf = new PDFTransporte('L', 'mm', 'Letter');
$pdf->SetMargins(15, 15, 15);
$pdf->AliasNbPages();
$pdf->AddPage();

// Agregar encabezado de columnas
$pdf->agregarEncabezadoColumnas();

// Agregar filas con los datos consolidados
foreach ($datosTransporte as $dato) {
    $pdf->agregarFila(
        $dato['FechaCompleta'],
        $dato['CantidadCajas'],
        $dato['PesoNeto'],
        $dato['PesoBruto'],
        $dato['GuiaMaster'],
        $dato['GuiaHija'],
        $dato['CantidadEstibas'],
        $dato['CantidadEstibasPagas'],
        $dato['CostoTransporte'],
        $dato['Facturas'],
        $dato['Precintos']
    );
}

// Agregar totales al final
$pdf->agregarTotales();

// Si no hay datos
if (empty($datosTransporte)) {
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(0, 10, utf8_decode('No se encontraron datos para el período seleccionado.'), 0, 1, 'C');
}

// Generar PDF
$nombreArchivo = 'Transporte_Consolidado_' . date('Y-m-d_His') . '.pdf'; // 👈 Nuevo nombre para evitar cache
$pdf->Output('I', $nombreArchivo);
